#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBGainGuardian[] cacheNTBGainGuardian;

		
		public NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			return NTBGainGuardian(Input, plusBE, moveBE, posIncrement, enableScaleOut, enableFlattenPosition, stopBE_bg, stopBE_fontColor, buyBE_bg, buyBE_fontColor, sellBE_bg, sellBE_fontColor, moveBE_bg, moveBE_fontColor);
		}


		
		public NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(ISeries<double> input, int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			if (cacheNTBGainGuardian != null)
				for (int idx = 0; idx < cacheNTBGainGuardian.Length; idx++)
					if (cacheNTBGainGuardian[idx].plusBE == plusBE && cacheNTBGainGuardian[idx].moveBE == moveBE && cacheNTBGainGuardian[idx].posIncrement == posIncrement && cacheNTBGainGuardian[idx].enableScaleOut == enableScaleOut && cacheNTBGainGuardian[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBGainGuardian[idx].stopBE_bg == stopBE_bg && cacheNTBGainGuardian[idx].stopBE_fontColor == stopBE_fontColor && cacheNTBGainGuardian[idx].buyBE_bg == buyBE_bg && cacheNTBGainGuardian[idx].buyBE_fontColor == buyBE_fontColor && cacheNTBGainGuardian[idx].sellBE_bg == sellBE_bg && cacheNTBGainGuardian[idx].sellBE_fontColor == sellBE_fontColor && cacheNTBGainGuardian[idx].moveBE_bg == moveBE_bg && cacheNTBGainGuardian[idx].moveBE_fontColor == moveBE_fontColor && cacheNTBGainGuardian[idx].EqualsInput(input))
						return cacheNTBGainGuardian[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBGainGuardian>(new NeoTraderBot_Tools.NTBGainGuardian(){ plusBE = plusBE, moveBE = moveBE, posIncrement = posIncrement, enableScaleOut = enableScaleOut, enableFlattenPosition = enableFlattenPosition, stopBE_bg = stopBE_bg, stopBE_fontColor = stopBE_fontColor, buyBE_bg = buyBE_bg, buyBE_fontColor = buyBE_fontColor, sellBE_bg = sellBE_bg, sellBE_fontColor = sellBE_fontColor, moveBE_bg = moveBE_bg, moveBE_fontColor = moveBE_fontColor }, input, ref cacheNTBGainGuardian);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			return indicator.NTBGainGuardian(Input, plusBE, moveBE, posIncrement, enableScaleOut, enableFlattenPosition, stopBE_bg, stopBE_fontColor, buyBE_bg, buyBE_fontColor, sellBE_bg, sellBE_fontColor, moveBE_bg, moveBE_fontColor);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(ISeries<double> input , int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			return indicator.NTBGainGuardian(input, plusBE, moveBE, posIncrement, enableScaleOut, enableFlattenPosition, stopBE_bg, stopBE_fontColor, buyBE_bg, buyBE_fontColor, sellBE_bg, sellBE_fontColor, moveBE_bg, moveBE_fontColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			return indicator.NTBGainGuardian(Input, plusBE, moveBE, posIncrement, enableScaleOut, enableFlattenPosition, stopBE_bg, stopBE_fontColor, buyBE_bg, buyBE_fontColor, sellBE_bg, sellBE_fontColor, moveBE_bg, moveBE_fontColor);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBGainGuardian NTBGainGuardian(ISeries<double> input , int plusBE, int moveBE, int posIncrement, bool enableScaleOut, bool enableFlattenPosition, Brush stopBE_bg, Brush stopBE_fontColor, Brush buyBE_bg, Brush buyBE_fontColor, Brush sellBE_bg, Brush sellBE_fontColor, Brush moveBE_bg, Brush moveBE_fontColor)
		{
			return indicator.NTBGainGuardian(input, plusBE, moveBE, posIncrement, enableScaleOut, enableFlattenPosition, stopBE_bg, stopBE_fontColor, buyBE_bg, buyBE_fontColor, sellBE_bg, sellBE_fontColor, moveBE_bg, moveBE_fontColor);
		}

	}
}

#endregion
