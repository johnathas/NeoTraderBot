#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Indicators.NTBFlashClick[] cacheNTBFlashClick;

		
		public NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			return NTBFlashClick(Input, stopOrderType, buyKey, sellKey, plotATMLines, entryLine, takeProfitLine, stopLossLine, textColor, backgroundColor, infoBoxOpacity);
		}


		
		public NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(ISeries<double> input, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			if (cacheNTBFlashClick != null)
				for (int idx = 0; idx < cacheNTBFlashClick.Length; idx++)
					if (cacheNTBFlashClick[idx].StopOrderType == stopOrderType && cacheNTBFlashClick[idx].BuyKey == buyKey && cacheNTBFlashClick[idx].SellKey == sellKey && cacheNTBFlashClick[idx].PlotATMLines == plotATMLines && cacheNTBFlashClick[idx].EntryLine == entryLine && cacheNTBFlashClick[idx].TakeProfitLine == takeProfitLine && cacheNTBFlashClick[idx].StopLossLine == stopLossLine && cacheNTBFlashClick[idx].TextColor == textColor && cacheNTBFlashClick[idx].BackgroundColor == backgroundColor && cacheNTBFlashClick[idx].InfoBoxOpacity == infoBoxOpacity && cacheNTBFlashClick[idx].EqualsInput(input))
						return cacheNTBFlashClick[idx];
			return CacheIndicator<NeoTraderBot_Indicators.NTBFlashClick>(new NeoTraderBot_Indicators.NTBFlashClick(){ StopOrderType = stopOrderType, BuyKey = buyKey, SellKey = sellKey, PlotATMLines = plotATMLines, EntryLine = entryLine, TakeProfitLine = takeProfitLine, StopLossLine = stopLossLine, TextColor = textColor, BackgroundColor = backgroundColor, InfoBoxOpacity = infoBoxOpacity }, input, ref cacheNTBFlashClick);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			return indicator.NTBFlashClick(Input, stopOrderType, buyKey, sellKey, plotATMLines, entryLine, takeProfitLine, stopLossLine, textColor, backgroundColor, infoBoxOpacity);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(ISeries<double> input , StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			return indicator.NTBFlashClick(input, stopOrderType, buyKey, sellKey, plotATMLines, entryLine, takeProfitLine, stopLossLine, textColor, backgroundColor, infoBoxOpacity);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			return indicator.NTBFlashClick(Input, stopOrderType, buyKey, sellKey, plotATMLines, entryLine, takeProfitLine, stopLossLine, textColor, backgroundColor, infoBoxOpacity);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBFlashClick NTBFlashClick(ISeries<double> input , StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool plotATMLines, Brush entryLine, Brush takeProfitLine, Brush stopLossLine, Brush textColor, Brush backgroundColor, int infoBoxOpacity)
		{
			return indicator.NTBFlashClick(input, stopOrderType, buyKey, sellKey, plotATMLines, entryLine, takeProfitLine, stopLossLine, textColor, backgroundColor, infoBoxOpacity);
		}

	}
}

#endregion
