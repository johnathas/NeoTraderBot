#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC[] cacheNTBTradeSafePTBR_BASIC;

		
		public NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return NTBTradeSafePTBR_BASIC(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, placeTargetStopInChart, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0, showTargetStopButtons, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(ISeries<double> input, bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			if (cacheNTBTradeSafePTBR_BASIC != null)
				for (int idx = 0; idx < cacheNTBTradeSafePTBR_BASIC.Length; idx++)
					if (cacheNTBTradeSafePTBR_BASIC[idx].DailyGoalLossPriceEnable == dailyGoalLossPriceEnable && cacheNTBTradeSafePTBR_BASIC[idx].FlattenWhenDailyLossTargetReached == flattenWhenDailyLossTargetReached && cacheNTBTradeSafePTBR_BASIC[idx].dailyTargetTrading == dailyTargetTrading && cacheNTBTradeSafePTBR_BASIC[idx].dailyStopTrading == dailyStopTrading && cacheNTBTradeSafePTBR_BASIC[idx].placeTargetStopInChart == placeTargetStopInChart && cacheNTBTradeSafePTBR_BASIC[idx].TDDAgreementTerm == tDDAgreementTerm && cacheNTBTradeSafePTBR_BASIC[idx].ResetRiskInfo == resetRiskInfo && cacheNTBTradeSafePTBR_BASIC[idx].TDDAutoLiquidatePeakBalance == tDDAutoLiquidatePeakBalance && cacheNTBTradeSafePTBR_BASIC[idx].TDDAutoLiquidateThreshold == tDDAutoLiquidateThreshold && cacheNTBTradeSafePTBR_BASIC[idx].ISThresholdTrailling == iSThresholdTrailling && cacheNTBTradeSafePTBR_BASIC[idx].InitialBalanceAccount == initialBalanceAccount && cacheNTBTradeSafePTBR_BASIC[idx].TargetGoalAccountThreshold == targetGoalAccountThreshold && cacheNTBTradeSafePTBR_BASIC[idx].TDDPriceEnable == tDDPriceEnable && cacheNTBTradeSafePTBR_BASIC[idx].AccountGoalPriceEnable == accountGoalPriceEnable && cacheNTBTradeSafePTBR_BASIC[idx].FlattenWhenGoalAccountReached == flattenWhenGoalAccountReached && cacheNTBTradeSafePTBR_BASIC[idx].tradingFromChart == tradingFromChart && cacheNTBTradeSafePTBR_BASIC[idx].StopOrderType == stopOrderType && cacheNTBTradeSafePTBR_BASIC[idx].BuyKey == buyKey && cacheNTBTradeSafePTBR_BASIC[idx].SellKey == sellKey && cacheNTBTradeSafePTBR_BASIC[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBTradeSafePTBR_BASIC[idx].AverageFIFOPriceEnable == averageFIFOPriceEnable && cacheNTBTradeSafePTBR_BASIC[idx].ordersHelperEnable == ordersHelperEnable && cacheNTBTradeSafePTBR_BASIC[idx].filenameTargetAlarm == filenameTargetAlarm && cacheNTBTradeSafePTBR_BASIC[idx].filenameStopAlarm == filenameStopAlarm && cacheNTBTradeSafePTBR_BASIC[idx].metaFrase0 == metaFrase0 && cacheNTBTradeSafePTBR_BASIC[idx].stopFrase0 == stopFrase0 && cacheNTBTradeSafePTBR_BASIC[idx].showTargetStopButtons == showTargetStopButtons && cacheNTBTradeSafePTBR_BASIC[idx].shortTargetTrade == shortTargetTrade && cacheNTBTradeSafePTBR_BASIC[idx].medTargetTrade == medTargetTrade && cacheNTBTradeSafePTBR_BASIC[idx].longTargetTrade == longTargetTrade && cacheNTBTradeSafePTBR_BASIC[idx].shortStopTrade == shortStopTrade && cacheNTBTradeSafePTBR_BASIC[idx].medStopTrade == medStopTrade && cacheNTBTradeSafePTBR_BASIC[idx].longStopTrade == longStopTrade && cacheNTBTradeSafePTBR_BASIC[idx].TrailPeakPriceEnable == trailPeakPriceEnable && cacheNTBTradeSafePTBR_BASIC[idx].trailStopBarClose == trailStopBarClose && cacheNTBTradeSafePTBR_BASIC[idx].trailStopUnit == trailStopUnit && cacheNTBTradeSafePTBR_BASIC[idx].trailStopOffset == trailStopOffset && cacheNTBTradeSafePTBR_BASIC[idx].MoveStopMarkersEnable == moveStopMarkersEnable && cacheNTBTradeSafePTBR_BASIC[idx].mvStop1 == mvStop1 && cacheNTBTradeSafePTBR_BASIC[idx].mvStop2 == mvStop2 && cacheNTBTradeSafePTBR_BASIC[idx].mvStop3 == mvStop3 && cacheNTBTradeSafePTBR_BASIC[idx].EqualsInput(input))
						return cacheNTBTradeSafePTBR_BASIC[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC>(new NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC(){ DailyGoalLossPriceEnable = dailyGoalLossPriceEnable, FlattenWhenDailyLossTargetReached = flattenWhenDailyLossTargetReached, dailyTargetTrading = dailyTargetTrading, dailyStopTrading = dailyStopTrading, placeTargetStopInChart = placeTargetStopInChart, TDDAgreementTerm = tDDAgreementTerm, ResetRiskInfo = resetRiskInfo, TDDAutoLiquidatePeakBalance = tDDAutoLiquidatePeakBalance, TDDAutoLiquidateThreshold = tDDAutoLiquidateThreshold, ISThresholdTrailling = iSThresholdTrailling, InitialBalanceAccount = initialBalanceAccount, TargetGoalAccountThreshold = targetGoalAccountThreshold, TDDPriceEnable = tDDPriceEnable, AccountGoalPriceEnable = accountGoalPriceEnable, FlattenWhenGoalAccountReached = flattenWhenGoalAccountReached, tradingFromChart = tradingFromChart, StopOrderType = stopOrderType, BuyKey = buyKey, SellKey = sellKey, enableFlattenPosition = enableFlattenPosition, AverageFIFOPriceEnable = averageFIFOPriceEnable, ordersHelperEnable = ordersHelperEnable, filenameTargetAlarm = filenameTargetAlarm, filenameStopAlarm = filenameStopAlarm, metaFrase0 = metaFrase0, stopFrase0 = stopFrase0, showTargetStopButtons = showTargetStopButtons, shortTargetTrade = shortTargetTrade, medTargetTrade = medTargetTrade, longTargetTrade = longTargetTrade, shortStopTrade = shortStopTrade, medStopTrade = medStopTrade, longStopTrade = longStopTrade, TrailPeakPriceEnable = trailPeakPriceEnable, trailStopBarClose = trailStopBarClose, trailStopUnit = trailStopUnit, trailStopOffset = trailStopOffset, MoveStopMarkersEnable = moveStopMarkersEnable, mvStop1 = mvStop1, mvStop2 = mvStop2, mvStop3 = mvStop3 }, input, ref cacheNTBTradeSafePTBR_BASIC);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBTradeSafePTBR_BASIC(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, placeTargetStopInChart, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0, showTargetStopButtons, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBTradeSafePTBR_BASIC(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, placeTargetStopInChart, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0, showTargetStopButtons, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBTradeSafePTBR_BASIC(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, placeTargetStopInChart, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0, showTargetStopButtons, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR_BASIC NTBTradeSafePTBR_BASIC(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool placeTargetStopInChart, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR_BASIC stopOrderType, DesiredKeyTradeSafePTBR_BASIC buyKey, DesiredKeyTradeSafePTBR_BASIC sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0, bool showTargetStopButtons, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR_BASIC trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBTradeSafePTBR_BASIC(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, placeTargetStopInChart, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0, showTargetStopButtons, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}

	}
}

#endregion
