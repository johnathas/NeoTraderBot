#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBTradeSafePTBR[] cacheNTBTradeSafePTBR;

		
		public NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return NTBTradeSafePTBR(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(ISeries<double> input, bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			if (cacheNTBTradeSafePTBR != null)
				for (int idx = 0; idx < cacheNTBTradeSafePTBR.Length; idx++)
					if (cacheNTBTradeSafePTBR[idx].DailyGoalLossPriceEnable == dailyGoalLossPriceEnable && cacheNTBTradeSafePTBR[idx].FlattenWhenDailyLossTargetReached == flattenWhenDailyLossTargetReached && cacheNTBTradeSafePTBR[idx].dailyTargetTrading == dailyTargetTrading && cacheNTBTradeSafePTBR[idx].dailyStopTrading == dailyStopTrading && cacheNTBTradeSafePTBR[idx].showTargetStopButtons == showTargetStopButtons && cacheNTBTradeSafePTBR[idx].placeTargetStopInChart == placeTargetStopInChart && cacheNTBTradeSafePTBR[idx].shortTargetTrade == shortTargetTrade && cacheNTBTradeSafePTBR[idx].medTargetTrade == medTargetTrade && cacheNTBTradeSafePTBR[idx].longTargetTrade == longTargetTrade && cacheNTBTradeSafePTBR[idx].shortStopTrade == shortStopTrade && cacheNTBTradeSafePTBR[idx].medStopTrade == medStopTrade && cacheNTBTradeSafePTBR[idx].longStopTrade == longStopTrade && cacheNTBTradeSafePTBR[idx].TrailPeakPriceEnable == trailPeakPriceEnable && cacheNTBTradeSafePTBR[idx].trailStopBarClose == trailStopBarClose && cacheNTBTradeSafePTBR[idx].trailStopUnit == trailStopUnit && cacheNTBTradeSafePTBR[idx].trailStopOffset == trailStopOffset && cacheNTBTradeSafePTBR[idx].MoveStopMarkersEnable == moveStopMarkersEnable && cacheNTBTradeSafePTBR[idx].mvStop1 == mvStop1 && cacheNTBTradeSafePTBR[idx].mvStop2 == mvStop2 && cacheNTBTradeSafePTBR[idx].mvStop3 == mvStop3 && cacheNTBTradeSafePTBR[idx].TDDAgreementTerm == tDDAgreementTerm && cacheNTBTradeSafePTBR[idx].ResetRiskInfo == resetRiskInfo && cacheNTBTradeSafePTBR[idx].TDDAutoLiquidatePeakBalance == tDDAutoLiquidatePeakBalance && cacheNTBTradeSafePTBR[idx].TDDAutoLiquidateThreshold == tDDAutoLiquidateThreshold && cacheNTBTradeSafePTBR[idx].ISThresholdTrailling == iSThresholdTrailling && cacheNTBTradeSafePTBR[idx].InitialBalanceAccount == initialBalanceAccount && cacheNTBTradeSafePTBR[idx].TargetGoalAccountThreshold == targetGoalAccountThreshold && cacheNTBTradeSafePTBR[idx].TDDPriceEnable == tDDPriceEnable && cacheNTBTradeSafePTBR[idx].AccountGoalPriceEnable == accountGoalPriceEnable && cacheNTBTradeSafePTBR[idx].FlattenWhenGoalAccountReached == flattenWhenGoalAccountReached && cacheNTBTradeSafePTBR[idx].tradingFromChart == tradingFromChart && cacheNTBTradeSafePTBR[idx].StopOrderType == stopOrderType && cacheNTBTradeSafePTBR[idx].BuyKey == buyKey && cacheNTBTradeSafePTBR[idx].SellKey == sellKey && cacheNTBTradeSafePTBR[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBTradeSafePTBR[idx].AverageFIFOPriceEnable == averageFIFOPriceEnable && cacheNTBTradeSafePTBR[idx].ordersHelperEnable == ordersHelperEnable && cacheNTBTradeSafePTBR[idx].filenameTargetAlarm == filenameTargetAlarm && cacheNTBTradeSafePTBR[idx].filenameStopAlarm == filenameStopAlarm && cacheNTBTradeSafePTBR[idx].metaFrase0 == metaFrase0 && cacheNTBTradeSafePTBR[idx].stopFrase0 == stopFrase0 && cacheNTBTradeSafePTBR[idx].EqualsInput(input))
						return cacheNTBTradeSafePTBR[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBTradeSafePTBR>(new NeoTraderBot_Tools.NTBTradeSafePTBR(){ DailyGoalLossPriceEnable = dailyGoalLossPriceEnable, FlattenWhenDailyLossTargetReached = flattenWhenDailyLossTargetReached, dailyTargetTrading = dailyTargetTrading, dailyStopTrading = dailyStopTrading, showTargetStopButtons = showTargetStopButtons, placeTargetStopInChart = placeTargetStopInChart, shortTargetTrade = shortTargetTrade, medTargetTrade = medTargetTrade, longTargetTrade = longTargetTrade, shortStopTrade = shortStopTrade, medStopTrade = medStopTrade, longStopTrade = longStopTrade, TrailPeakPriceEnable = trailPeakPriceEnable, trailStopBarClose = trailStopBarClose, trailStopUnit = trailStopUnit, trailStopOffset = trailStopOffset, MoveStopMarkersEnable = moveStopMarkersEnable, mvStop1 = mvStop1, mvStop2 = mvStop2, mvStop3 = mvStop3, TDDAgreementTerm = tDDAgreementTerm, ResetRiskInfo = resetRiskInfo, TDDAutoLiquidatePeakBalance = tDDAutoLiquidatePeakBalance, TDDAutoLiquidateThreshold = tDDAutoLiquidateThreshold, ISThresholdTrailling = iSThresholdTrailling, InitialBalanceAccount = initialBalanceAccount, TargetGoalAccountThreshold = targetGoalAccountThreshold, TDDPriceEnable = tDDPriceEnable, AccountGoalPriceEnable = accountGoalPriceEnable, FlattenWhenGoalAccountReached = flattenWhenGoalAccountReached, tradingFromChart = tradingFromChart, StopOrderType = stopOrderType, BuyKey = buyKey, SellKey = sellKey, enableFlattenPosition = enableFlattenPosition, AverageFIFOPriceEnable = averageFIFOPriceEnable, ordersHelperEnable = ordersHelperEnable, filenameTargetAlarm = filenameTargetAlarm, filenameStopAlarm = filenameStopAlarm, metaFrase0 = metaFrase0, stopFrase0 = stopFrase0 }, input, ref cacheNTBTradeSafePTBR);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafePTBR(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafePTBR(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafePTBR(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafePTBR NTBTradeSafePTBR(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafePTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafePTBR stopOrderType, DesiredKeyTradeSafePTBR buyKey, DesiredKeyTradeSafePTBR sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafePTBR(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}

	}
}

#endregion
