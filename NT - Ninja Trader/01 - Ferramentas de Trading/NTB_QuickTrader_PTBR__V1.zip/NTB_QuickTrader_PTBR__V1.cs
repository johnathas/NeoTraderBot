#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBQuickTraderPTBR[] cacheNTBQuickTraderPTBR;

		
		public NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			return NTBQuickTraderPTBR(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, trailPriceDashed, trailPriceWidth, trailPriceEnableTextBox, trailPriceTextBoxPosition, trailPriceTextBoxFont, targetStopPreviewPriceDashed, targetStopPreviewPriceWidth, targetStopPreviewPriceEnableTextBox, targetStopPreviewPriceTextBoxPosition, targetStopPreviewPriceTextBoxFont, moveStopMarkersWidth, moveStopMarkersTextBoxEnable);
		}


		
		public NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(ISeries<double> input, bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			if (cacheNTBQuickTraderPTBR != null)
				for (int idx = 0; idx < cacheNTBQuickTraderPTBR.Length; idx++)
					if (cacheNTBQuickTraderPTBR[idx].showTargetStopButtons == showTargetStopButtons && cacheNTBQuickTraderPTBR[idx].placeTargetStopInChart == placeTargetStopInChart && cacheNTBQuickTraderPTBR[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBQuickTraderPTBR[idx].shortTargetTrade == shortTargetTrade && cacheNTBQuickTraderPTBR[idx].medTargetTrade == medTargetTrade && cacheNTBQuickTraderPTBR[idx].longTargetTrade == longTargetTrade && cacheNTBQuickTraderPTBR[idx].shortStopTrade == shortStopTrade && cacheNTBQuickTraderPTBR[idx].medStopTrade == medStopTrade && cacheNTBQuickTraderPTBR[idx].longStopTrade == longStopTrade && cacheNTBQuickTraderPTBR[idx].TrailPeakPriceEnable == trailPeakPriceEnable && cacheNTBQuickTraderPTBR[idx].trailStopBarClose == trailStopBarClose && cacheNTBQuickTraderPTBR[idx].trailStopUnit == trailStopUnit && cacheNTBQuickTraderPTBR[idx].trailStopOffset == trailStopOffset && cacheNTBQuickTraderPTBR[idx].MoveStopMarkersEnable == moveStopMarkersEnable && cacheNTBQuickTraderPTBR[idx].mvStop1 == mvStop1 && cacheNTBQuickTraderPTBR[idx].mvStop2 == mvStop2 && cacheNTBQuickTraderPTBR[idx].mvStop3 == mvStop3 && cacheNTBQuickTraderPTBR[idx].TrailPriceDashed == trailPriceDashed && cacheNTBQuickTraderPTBR[idx].TrailPriceWidth == trailPriceWidth && cacheNTBQuickTraderPTBR[idx].TrailPriceEnableTextBox == trailPriceEnableTextBox && cacheNTBQuickTraderPTBR[idx].TrailPriceTextBoxPosition == trailPriceTextBoxPosition && cacheNTBQuickTraderPTBR[idx].TrailPriceTextBoxFont == trailPriceTextBoxFont && cacheNTBQuickTraderPTBR[idx].TargetStopPreviewPriceDashed == targetStopPreviewPriceDashed && cacheNTBQuickTraderPTBR[idx].TargetStopPreviewPriceWidth == targetStopPreviewPriceWidth && cacheNTBQuickTraderPTBR[idx].TargetStopPreviewPriceEnableTextBox == targetStopPreviewPriceEnableTextBox && cacheNTBQuickTraderPTBR[idx].TargetStopPreviewPriceTextBoxPosition == targetStopPreviewPriceTextBoxPosition && cacheNTBQuickTraderPTBR[idx].TargetStopPreviewPriceTextBoxFont == targetStopPreviewPriceTextBoxFont && cacheNTBQuickTraderPTBR[idx].MoveStopMarkersWidth == moveStopMarkersWidth && cacheNTBQuickTraderPTBR[idx].MoveStopMarkersTextBoxEnable == moveStopMarkersTextBoxEnable && cacheNTBQuickTraderPTBR[idx].EqualsInput(input))
						return cacheNTBQuickTraderPTBR[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBQuickTraderPTBR>(new NeoTraderBot_Tools.NTBQuickTraderPTBR(){ showTargetStopButtons = showTargetStopButtons, placeTargetStopInChart = placeTargetStopInChart, enableFlattenPosition = enableFlattenPosition, shortTargetTrade = shortTargetTrade, medTargetTrade = medTargetTrade, longTargetTrade = longTargetTrade, shortStopTrade = shortStopTrade, medStopTrade = medStopTrade, longStopTrade = longStopTrade, TrailPeakPriceEnable = trailPeakPriceEnable, trailStopBarClose = trailStopBarClose, trailStopUnit = trailStopUnit, trailStopOffset = trailStopOffset, MoveStopMarkersEnable = moveStopMarkersEnable, mvStop1 = mvStop1, mvStop2 = mvStop2, mvStop3 = mvStop3, TrailPriceDashed = trailPriceDashed, TrailPriceWidth = trailPriceWidth, TrailPriceEnableTextBox = trailPriceEnableTextBox, TrailPriceTextBoxPosition = trailPriceTextBoxPosition, TrailPriceTextBoxFont = trailPriceTextBoxFont, TargetStopPreviewPriceDashed = targetStopPreviewPriceDashed, TargetStopPreviewPriceWidth = targetStopPreviewPriceWidth, TargetStopPreviewPriceEnableTextBox = targetStopPreviewPriceEnableTextBox, TargetStopPreviewPriceTextBoxPosition = targetStopPreviewPriceTextBoxPosition, TargetStopPreviewPriceTextBoxFont = targetStopPreviewPriceTextBoxFont, MoveStopMarkersWidth = moveStopMarkersWidth, MoveStopMarkersTextBoxEnable = moveStopMarkersTextBoxEnable }, input, ref cacheNTBQuickTraderPTBR);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			return indicator.NTBQuickTraderPTBR(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, trailPriceDashed, trailPriceWidth, trailPriceEnableTextBox, trailPriceTextBoxPosition, trailPriceTextBoxFont, targetStopPreviewPriceDashed, targetStopPreviewPriceWidth, targetStopPreviewPriceEnableTextBox, targetStopPreviewPriceTextBoxPosition, targetStopPreviewPriceTextBoxFont, moveStopMarkersWidth, moveStopMarkersTextBoxEnable);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(ISeries<double> input , bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			return indicator.NTBQuickTraderPTBR(input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, trailPriceDashed, trailPriceWidth, trailPriceEnableTextBox, trailPriceTextBoxPosition, trailPriceTextBoxFont, targetStopPreviewPriceDashed, targetStopPreviewPriceWidth, targetStopPreviewPriceEnableTextBox, targetStopPreviewPriceTextBoxPosition, targetStopPreviewPriceTextBoxFont, moveStopMarkersWidth, moveStopMarkersTextBoxEnable);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			return indicator.NTBQuickTraderPTBR(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, trailPriceDashed, trailPriceWidth, trailPriceEnableTextBox, trailPriceTextBoxPosition, trailPriceTextBoxFont, targetStopPreviewPriceDashed, targetStopPreviewPriceWidth, targetStopPreviewPriceEnableTextBox, targetStopPreviewPriceTextBoxPosition, targetStopPreviewPriceTextBoxFont, moveStopMarkersWidth, moveStopMarkersTextBoxEnable);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderPTBR NTBQuickTraderPTBR(ISeries<double> input , bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderPTBR trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool trailPriceDashed, int trailPriceWidth, bool trailPriceEnableTextBox, int trailPriceTextBoxPosition, SimpleFont trailPriceTextBoxFont, bool targetStopPreviewPriceDashed, int targetStopPreviewPriceWidth, bool targetStopPreviewPriceEnableTextBox, int targetStopPreviewPriceTextBoxPosition, SimpleFont targetStopPreviewPriceTextBoxFont, int moveStopMarkersWidth, bool moveStopMarkersTextBoxEnable)
		{
			return indicator.NTBQuickTraderPTBR(input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, trailPriceDashed, trailPriceWidth, trailPriceEnableTextBox, trailPriceTextBoxPosition, trailPriceTextBoxFont, targetStopPreviewPriceDashed, targetStopPreviewPriceWidth, targetStopPreviewPriceEnableTextBox, targetStopPreviewPriceTextBoxPosition, targetStopPreviewPriceTextBoxFont, moveStopMarkersWidth, moveStopMarkersTextBoxEnable);
		}

	}
}

#endregion
