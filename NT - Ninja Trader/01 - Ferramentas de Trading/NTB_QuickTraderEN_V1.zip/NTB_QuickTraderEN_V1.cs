#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBQuickTraderEN[] cacheNTBQuickTraderEN;

		
		public NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return NTBQuickTraderEN(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(ISeries<double> input, bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			if (cacheNTBQuickTraderEN != null)
				for (int idx = 0; idx < cacheNTBQuickTraderEN.Length; idx++)
					if (cacheNTBQuickTraderEN[idx].showTargetStopButtons == showTargetStopButtons && cacheNTBQuickTraderEN[idx].placeTargetStopInChart == placeTargetStopInChart && cacheNTBQuickTraderEN[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBQuickTraderEN[idx].shortTargetTrade == shortTargetTrade && cacheNTBQuickTraderEN[idx].medTargetTrade == medTargetTrade && cacheNTBQuickTraderEN[idx].longTargetTrade == longTargetTrade && cacheNTBQuickTraderEN[idx].shortStopTrade == shortStopTrade && cacheNTBQuickTraderEN[idx].medStopTrade == medStopTrade && cacheNTBQuickTraderEN[idx].longStopTrade == longStopTrade && cacheNTBQuickTraderEN[idx].TrailPeakPriceEnable == trailPeakPriceEnable && cacheNTBQuickTraderEN[idx].trailStopBarClose == trailStopBarClose && cacheNTBQuickTraderEN[idx].trailStopUnit == trailStopUnit && cacheNTBQuickTraderEN[idx].trailStopOffset == trailStopOffset && cacheNTBQuickTraderEN[idx].MoveStopMarkersEnable == moveStopMarkersEnable && cacheNTBQuickTraderEN[idx].mvStop1 == mvStop1 && cacheNTBQuickTraderEN[idx].mvStop2 == mvStop2 && cacheNTBQuickTraderEN[idx].mvStop3 == mvStop3 && cacheNTBQuickTraderEN[idx].EqualsInput(input))
						return cacheNTBQuickTraderEN[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBQuickTraderEN>(new NeoTraderBot_Tools.NTBQuickTraderEN(){ showTargetStopButtons = showTargetStopButtons, placeTargetStopInChart = placeTargetStopInChart, enableFlattenPosition = enableFlattenPosition, shortTargetTrade = shortTargetTrade, medTargetTrade = medTargetTrade, longTargetTrade = longTargetTrade, shortStopTrade = shortStopTrade, medStopTrade = medStopTrade, longStopTrade = longStopTrade, TrailPeakPriceEnable = trailPeakPriceEnable, trailStopBarClose = trailStopBarClose, trailStopUnit = trailStopUnit, trailStopOffset = trailStopOffset, MoveStopMarkersEnable = moveStopMarkersEnable, mvStop1 = mvStop1, mvStop2 = mvStop2, mvStop3 = mvStop3 }, input, ref cacheNTBQuickTraderEN);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBQuickTraderEN(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(ISeries<double> input , bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBQuickTraderEN(input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBQuickTraderEN(Input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBQuickTraderEN NTBQuickTraderEN(ISeries<double> input , bool showTargetStopButtons, bool placeTargetStopInChart, bool enableFlattenPosition, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitQuickTraderEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3)
		{
			return indicator.NTBQuickTraderEN(input, showTargetStopButtons, placeTargetStopInChart, enableFlattenPosition, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3);
		}

	}
}

#endregion
