#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBFlashClick[] cacheNTBFlashClick;

		
		public NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			return NTBFlashClick(Input, topBarAlignment, stopOrderType, buyKey, sellKey, enableFlattenShortcut, plotATMLines, entryLineColor, entryPriceEnableTextBox, entryPriceTextBoxPosition, entryPriceTextBoxColor, entryPriceTextBoxFont, entryPriceTextBoxFontColor, targetLineColor, targetPriceEnableTextBox, targetPriceTextBoxPosition, targetPriceTextBoxColor, targetPriceTextBoxFont, targetPriceTextBoxFontColor, stopLossLineColor, stopPriceEnableTextBox, stopPriceTextBoxPosition, stopPriceTextBoxColor, stopPriceTextBoxFont, stopPriceTextBoxFontColor);
		}


		
		public NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(ISeries<double> input, TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			if (cacheNTBFlashClick != null)
				for (int idx = 0; idx < cacheNTBFlashClick.Length; idx++)
					if (cacheNTBFlashClick[idx].TopBarAlignment == topBarAlignment && cacheNTBFlashClick[idx].StopOrderType == stopOrderType && cacheNTBFlashClick[idx].BuyKey == buyKey && cacheNTBFlashClick[idx].SellKey == sellKey && cacheNTBFlashClick[idx].EnableFlattenShortcut == enableFlattenShortcut && cacheNTBFlashClick[idx].PlotATMLines == plotATMLines && cacheNTBFlashClick[idx].EntryLineColor == entryLineColor && cacheNTBFlashClick[idx].EntryPriceEnableTextBox == entryPriceEnableTextBox && cacheNTBFlashClick[idx].EntryPriceTextBoxPosition == entryPriceTextBoxPosition && cacheNTBFlashClick[idx].EntryPriceTextBoxColor == entryPriceTextBoxColor && cacheNTBFlashClick[idx].EntryPriceTextBoxFont == entryPriceTextBoxFont && cacheNTBFlashClick[idx].EntryPriceTextBoxFontColor == entryPriceTextBoxFontColor && cacheNTBFlashClick[idx].TargetLineColor == targetLineColor && cacheNTBFlashClick[idx].TargetPriceEnableTextBox == targetPriceEnableTextBox && cacheNTBFlashClick[idx].TargetPriceTextBoxPosition == targetPriceTextBoxPosition && cacheNTBFlashClick[idx].TargetPriceTextBoxColor == targetPriceTextBoxColor && cacheNTBFlashClick[idx].TargetPriceTextBoxFont == targetPriceTextBoxFont && cacheNTBFlashClick[idx].TargetPriceTextBoxFontColor == targetPriceTextBoxFontColor && cacheNTBFlashClick[idx].StopLossLineColor == stopLossLineColor && cacheNTBFlashClick[idx].StopPriceEnableTextBox == stopPriceEnableTextBox && cacheNTBFlashClick[idx].StopPriceTextBoxPosition == stopPriceTextBoxPosition && cacheNTBFlashClick[idx].StopPriceTextBoxColor == stopPriceTextBoxColor && cacheNTBFlashClick[idx].StopPriceTextBoxFont == stopPriceTextBoxFont && cacheNTBFlashClick[idx].StopPriceTextBoxFontColor == stopPriceTextBoxFontColor && cacheNTBFlashClick[idx].EqualsInput(input))
						return cacheNTBFlashClick[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBFlashClick>(new NeoTraderBot_Tools.NTBFlashClick(){ TopBarAlignment = topBarAlignment, StopOrderType = stopOrderType, BuyKey = buyKey, SellKey = sellKey, EnableFlattenShortcut = enableFlattenShortcut, PlotATMLines = plotATMLines, EntryLineColor = entryLineColor, EntryPriceEnableTextBox = entryPriceEnableTextBox, EntryPriceTextBoxPosition = entryPriceTextBoxPosition, EntryPriceTextBoxColor = entryPriceTextBoxColor, EntryPriceTextBoxFont = entryPriceTextBoxFont, EntryPriceTextBoxFontColor = entryPriceTextBoxFontColor, TargetLineColor = targetLineColor, TargetPriceEnableTextBox = targetPriceEnableTextBox, TargetPriceTextBoxPosition = targetPriceTextBoxPosition, TargetPriceTextBoxColor = targetPriceTextBoxColor, TargetPriceTextBoxFont = targetPriceTextBoxFont, TargetPriceTextBoxFontColor = targetPriceTextBoxFontColor, StopLossLineColor = stopLossLineColor, StopPriceEnableTextBox = stopPriceEnableTextBox, StopPriceTextBoxPosition = stopPriceTextBoxPosition, StopPriceTextBoxColor = stopPriceTextBoxColor, StopPriceTextBoxFont = stopPriceTextBoxFont, StopPriceTextBoxFontColor = stopPriceTextBoxFontColor }, input, ref cacheNTBFlashClick);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			return indicator.NTBFlashClick(Input, topBarAlignment, stopOrderType, buyKey, sellKey, enableFlattenShortcut, plotATMLines, entryLineColor, entryPriceEnableTextBox, entryPriceTextBoxPosition, entryPriceTextBoxColor, entryPriceTextBoxFont, entryPriceTextBoxFontColor, targetLineColor, targetPriceEnableTextBox, targetPriceTextBoxPosition, targetPriceTextBoxColor, targetPriceTextBoxFont, targetPriceTextBoxFontColor, stopLossLineColor, stopPriceEnableTextBox, stopPriceTextBoxPosition, stopPriceTextBoxColor, stopPriceTextBoxFont, stopPriceTextBoxFontColor);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(ISeries<double> input , TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			return indicator.NTBFlashClick(input, topBarAlignment, stopOrderType, buyKey, sellKey, enableFlattenShortcut, plotATMLines, entryLineColor, entryPriceEnableTextBox, entryPriceTextBoxPosition, entryPriceTextBoxColor, entryPriceTextBoxFont, entryPriceTextBoxFontColor, targetLineColor, targetPriceEnableTextBox, targetPriceTextBoxPosition, targetPriceTextBoxColor, targetPriceTextBoxFont, targetPriceTextBoxFontColor, stopLossLineColor, stopPriceEnableTextBox, stopPriceTextBoxPosition, stopPriceTextBoxColor, stopPriceTextBoxFont, stopPriceTextBoxFontColor);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			return indicator.NTBFlashClick(Input, topBarAlignment, stopOrderType, buyKey, sellKey, enableFlattenShortcut, plotATMLines, entryLineColor, entryPriceEnableTextBox, entryPriceTextBoxPosition, entryPriceTextBoxColor, entryPriceTextBoxFont, entryPriceTextBoxFontColor, targetLineColor, targetPriceEnableTextBox, targetPriceTextBoxPosition, targetPriceTextBoxColor, targetPriceTextBoxFont, targetPriceTextBoxFontColor, stopLossLineColor, stopPriceEnableTextBox, stopPriceTextBoxPosition, stopPriceTextBoxColor, stopPriceTextBoxFont, stopPriceTextBoxFontColor);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBFlashClick NTBFlashClick(ISeries<double> input , TopBarFlashClickAlignment topBarAlignment, StopOrderTypes stopOrderType, DesiredKey buyKey, DesiredKey sellKey, bool enableFlattenShortcut, bool plotATMLines, Brush entryLineColor, bool entryPriceEnableTextBox, int entryPriceTextBoxPosition, Brush entryPriceTextBoxColor, SimpleFont entryPriceTextBoxFont, Brush entryPriceTextBoxFontColor, Brush targetLineColor, bool targetPriceEnableTextBox, int targetPriceTextBoxPosition, Brush targetPriceTextBoxColor, SimpleFont targetPriceTextBoxFont, Brush targetPriceTextBoxFontColor, Brush stopLossLineColor, bool stopPriceEnableTextBox, int stopPriceTextBoxPosition, Brush stopPriceTextBoxColor, SimpleFont stopPriceTextBoxFont, Brush stopPriceTextBoxFontColor)
		{
			return indicator.NTBFlashClick(input, topBarAlignment, stopOrderType, buyKey, sellKey, enableFlattenShortcut, plotATMLines, entryLineColor, entryPriceEnableTextBox, entryPriceTextBoxPosition, entryPriceTextBoxColor, entryPriceTextBoxFont, entryPriceTextBoxFontColor, targetLineColor, targetPriceEnableTextBox, targetPriceTextBoxPosition, targetPriceTextBoxColor, targetPriceTextBoxFont, targetPriceTextBoxFontColor, stopLossLineColor, stopPriceEnableTextBox, stopPriceTextBoxPosition, stopPriceTextBoxColor, stopPriceTextBoxFont, stopPriceTextBoxFontColor);
		}

	}
}

#endregion
