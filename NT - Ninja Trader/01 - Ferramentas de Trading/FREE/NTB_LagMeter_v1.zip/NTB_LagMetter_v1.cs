#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Indicators.NTBLagMeter[] cacheNTBLagMeter;

		
		public NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return NTBLagMeter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(ISeries<double> input, double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			if (cacheNTBLagMeter != null)
				for (int idx = 0; idx < cacheNTBLagMeter.Length; idx++)
					if (cacheNTBLagMeter[idx].treshold_lat == treshold_lat && cacheNTBLagMeter[idx].lastNTransations == lastNTransations && cacheNTBLagMeter[idx].showInfobox == showInfobox && cacheNTBLagMeter[idx].alertBackground == alertBackground && cacheNTBLagMeter[idx].bkgAlertColor == bkgAlertColor && cacheNTBLagMeter[idx].VerticalOffset == verticalOffset && cacheNTBLagMeter[idx].HorizontalOffset == horizontalOffset && cacheNTBLagMeter[idx].LabelTextBrush == labelTextBrush && cacheNTBLagMeter[idx].AreaBrush == areaBrush && cacheNTBLagMeter[idx].BorderBrush == borderBrush && cacheNTBLagMeter[idx].PositiveBrush == positiveBrush && cacheNTBLagMeter[idx].NegativeBrush == negativeBrush && cacheNTBLagMeter[idx].EqualsInput(input))
						return cacheNTBLagMeter[idx];
			return CacheIndicator<NeoTraderBot_Indicators.NTBLagMeter>(new NeoTraderBot_Indicators.NTBLagMeter(){ treshold_lat = treshold_lat, lastNTransations = lastNTransations, showInfobox = showInfobox, alertBackground = alertBackground, bkgAlertColor = bkgAlertColor, VerticalOffset = verticalOffset, HorizontalOffset = horizontalOffset, LabelTextBrush = labelTextBrush, AreaBrush = areaBrush, BorderBrush = borderBrush, PositiveBrush = positiveBrush, NegativeBrush = negativeBrush }, input, ref cacheNTBLagMeter);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMeter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(ISeries<double> input , double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMeter(input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMeter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBLagMeter NTBLagMeter(ISeries<double> input , double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMeter(input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}

	}
}

#endregion
