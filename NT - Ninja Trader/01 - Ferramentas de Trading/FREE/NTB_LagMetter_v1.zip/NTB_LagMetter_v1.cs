#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Indicators.NTBLagMetter[] cacheNTBLagMetter;

		
		public NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return NTBLagMetter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(ISeries<double> input, double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			if (cacheNTBLagMetter != null)
				for (int idx = 0; idx < cacheNTBLagMetter.Length; idx++)
					if (cacheNTBLagMetter[idx].treshold_lat == treshold_lat && cacheNTBLagMetter[idx].lastNTransations == lastNTransations && cacheNTBLagMetter[idx].showInfobox == showInfobox && cacheNTBLagMetter[idx].alertBackground == alertBackground && cacheNTBLagMetter[idx].bkgAlertColor == bkgAlertColor && cacheNTBLagMetter[idx].VerticalOffset == verticalOffset && cacheNTBLagMetter[idx].HorizontalOffset == horizontalOffset && cacheNTBLagMetter[idx].LabelTextBrush == labelTextBrush && cacheNTBLagMetter[idx].AreaBrush == areaBrush && cacheNTBLagMetter[idx].BorderBrush == borderBrush && cacheNTBLagMetter[idx].PositiveBrush == positiveBrush && cacheNTBLagMetter[idx].NegativeBrush == negativeBrush && cacheNTBLagMetter[idx].EqualsInput(input))
						return cacheNTBLagMetter[idx];
			return CacheIndicator<NeoTraderBot_Indicators.NTBLagMetter>(new NeoTraderBot_Indicators.NTBLagMetter(){ treshold_lat = treshold_lat, lastNTransations = lastNTransations, showInfobox = showInfobox, alertBackground = alertBackground, bkgAlertColor = bkgAlertColor, VerticalOffset = verticalOffset, HorizontalOffset = horizontalOffset, LabelTextBrush = labelTextBrush, AreaBrush = areaBrush, BorderBrush = borderBrush, PositiveBrush = positiveBrush, NegativeBrush = negativeBrush }, input, ref cacheNTBLagMetter);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMetter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(ISeries<double> input , double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMetter(input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMetter(Input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBLagMetter NTBLagMetter(ISeries<double> input , double treshold_lat, int lastNTransations, bool showInfobox, bool alertBackground, Brush bkgAlertColor, int verticalOffset, int horizontalOffset, Brush labelTextBrush, Brush areaBrush, Brush borderBrush, Brush positiveBrush, Brush negativeBrush)
		{
			return indicator.NTBLagMetter(input, treshold_lat, lastNTransations, showInfobox, alertBackground, bkgAlertColor, verticalOffset, horizontalOffset, labelTextBrush, areaBrush, borderBrush, positiveBrush, negativeBrush);
		}

	}
}

#endregion
