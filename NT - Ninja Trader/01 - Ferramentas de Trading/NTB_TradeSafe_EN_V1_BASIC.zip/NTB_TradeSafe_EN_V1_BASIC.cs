#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Tools.NTBTradeSafe_EN[] cacheNTBTradeSafe_EN;

		
		public NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return NTBTradeSafe_EN(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(ISeries<double> input, bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			if (cacheNTBTradeSafe_EN != null)
				for (int idx = 0; idx < cacheNTBTradeSafe_EN.Length; idx++)
					if (cacheNTBTradeSafe_EN[idx].DailyGoalLossPriceEnable == dailyGoalLossPriceEnable && cacheNTBTradeSafe_EN[idx].FlattenWhenDailyLossTargetReached == flattenWhenDailyLossTargetReached && cacheNTBTradeSafe_EN[idx].dailyTargetTrading == dailyTargetTrading && cacheNTBTradeSafe_EN[idx].dailyStopTrading == dailyStopTrading && cacheNTBTradeSafe_EN[idx].showTargetStopButtons == showTargetStopButtons && cacheNTBTradeSafe_EN[idx].placeTargetStopInChart == placeTargetStopInChart && cacheNTBTradeSafe_EN[idx].shortTargetTrade == shortTargetTrade && cacheNTBTradeSafe_EN[idx].medTargetTrade == medTargetTrade && cacheNTBTradeSafe_EN[idx].longTargetTrade == longTargetTrade && cacheNTBTradeSafe_EN[idx].shortStopTrade == shortStopTrade && cacheNTBTradeSafe_EN[idx].medStopTrade == medStopTrade && cacheNTBTradeSafe_EN[idx].longStopTrade == longStopTrade && cacheNTBTradeSafe_EN[idx].TrailPeakPriceEnable == trailPeakPriceEnable && cacheNTBTradeSafe_EN[idx].trailStopBarClose == trailStopBarClose && cacheNTBTradeSafe_EN[idx].trailStopUnit == trailStopUnit && cacheNTBTradeSafe_EN[idx].trailStopOffset == trailStopOffset && cacheNTBTradeSafe_EN[idx].MoveStopMarkersEnable == moveStopMarkersEnable && cacheNTBTradeSafe_EN[idx].mvStop1 == mvStop1 && cacheNTBTradeSafe_EN[idx].mvStop2 == mvStop2 && cacheNTBTradeSafe_EN[idx].mvStop3 == mvStop3 && cacheNTBTradeSafe_EN[idx].TDDAgreementTerm == tDDAgreementTerm && cacheNTBTradeSafe_EN[idx].ResetRiskInfo == resetRiskInfo && cacheNTBTradeSafe_EN[idx].TDDAutoLiquidatePeakBalance == tDDAutoLiquidatePeakBalance && cacheNTBTradeSafe_EN[idx].TDDAutoLiquidateThreshold == tDDAutoLiquidateThreshold && cacheNTBTradeSafe_EN[idx].ISThresholdTrailling == iSThresholdTrailling && cacheNTBTradeSafe_EN[idx].InitialBalanceAccount == initialBalanceAccount && cacheNTBTradeSafe_EN[idx].TargetGoalAccountThreshold == targetGoalAccountThreshold && cacheNTBTradeSafe_EN[idx].TDDPriceEnable == tDDPriceEnable && cacheNTBTradeSafe_EN[idx].AccountGoalPriceEnable == accountGoalPriceEnable && cacheNTBTradeSafe_EN[idx].FlattenWhenGoalAccountReached == flattenWhenGoalAccountReached && cacheNTBTradeSafe_EN[idx].tradingFromChart == tradingFromChart && cacheNTBTradeSafe_EN[idx].StopOrderType == stopOrderType && cacheNTBTradeSafe_EN[idx].BuyKey == buyKey && cacheNTBTradeSafe_EN[idx].SellKey == sellKey && cacheNTBTradeSafe_EN[idx].enableFlattenPosition == enableFlattenPosition && cacheNTBTradeSafe_EN[idx].AverageFIFOPriceEnable == averageFIFOPriceEnable && cacheNTBTradeSafe_EN[idx].ordersHelperEnable == ordersHelperEnable && cacheNTBTradeSafe_EN[idx].filenameTargetAlarm == filenameTargetAlarm && cacheNTBTradeSafe_EN[idx].filenameStopAlarm == filenameStopAlarm && cacheNTBTradeSafe_EN[idx].metaFrase0 == metaFrase0 && cacheNTBTradeSafe_EN[idx].stopFrase0 == stopFrase0 && cacheNTBTradeSafe_EN[idx].EqualsInput(input))
						return cacheNTBTradeSafe_EN[idx];
			return CacheIndicator<NeoTraderBot_Tools.NTBTradeSafe_EN>(new NeoTraderBot_Tools.NTBTradeSafe_EN(){ DailyGoalLossPriceEnable = dailyGoalLossPriceEnable, FlattenWhenDailyLossTargetReached = flattenWhenDailyLossTargetReached, dailyTargetTrading = dailyTargetTrading, dailyStopTrading = dailyStopTrading, showTargetStopButtons = showTargetStopButtons, placeTargetStopInChart = placeTargetStopInChart, shortTargetTrade = shortTargetTrade, medTargetTrade = medTargetTrade, longTargetTrade = longTargetTrade, shortStopTrade = shortStopTrade, medStopTrade = medStopTrade, longStopTrade = longStopTrade, TrailPeakPriceEnable = trailPeakPriceEnable, trailStopBarClose = trailStopBarClose, trailStopUnit = trailStopUnit, trailStopOffset = trailStopOffset, MoveStopMarkersEnable = moveStopMarkersEnable, mvStop1 = mvStop1, mvStop2 = mvStop2, mvStop3 = mvStop3, TDDAgreementTerm = tDDAgreementTerm, ResetRiskInfo = resetRiskInfo, TDDAutoLiquidatePeakBalance = tDDAutoLiquidatePeakBalance, TDDAutoLiquidateThreshold = tDDAutoLiquidateThreshold, ISThresholdTrailling = iSThresholdTrailling, InitialBalanceAccount = initialBalanceAccount, TargetGoalAccountThreshold = targetGoalAccountThreshold, TDDPriceEnable = tDDPriceEnable, AccountGoalPriceEnable = accountGoalPriceEnable, FlattenWhenGoalAccountReached = flattenWhenGoalAccountReached, tradingFromChart = tradingFromChart, StopOrderType = stopOrderType, BuyKey = buyKey, SellKey = sellKey, enableFlattenPosition = enableFlattenPosition, AverageFIFOPriceEnable = averageFIFOPriceEnable, ordersHelperEnable = ordersHelperEnable, filenameTargetAlarm = filenameTargetAlarm, filenameStopAlarm = filenameStopAlarm, metaFrase0 = metaFrase0, stopFrase0 = stopFrase0 }, input, ref cacheNTBTradeSafe_EN);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafe_EN(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafe_EN(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafe_EN(Input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}


		
		public Indicators.NeoTraderBot_Tools.NTBTradeSafe_EN NTBTradeSafe_EN(ISeries<double> input , bool dailyGoalLossPriceEnable, bool flattenWhenDailyLossTargetReached, int dailyTargetTrading, int dailyStopTrading, bool showTargetStopButtons, bool placeTargetStopInChart, double shortTargetTrade, double medTargetTrade, double longTargetTrade, double shortStopTrade, double medStopTrade, double longStopTrade, bool trailPeakPriceEnable, bool trailStopBarClose, trailUnitTradeSafeEN trailStopUnit, double trailStopOffset, bool moveStopMarkersEnable, double mvStop1, double mvStop2, double mvStop3, bool tDDAgreementTerm, bool resetRiskInfo, double tDDAutoLiquidatePeakBalance, double tDDAutoLiquidateThreshold, bool iSThresholdTrailling, double initialBalanceAccount, double targetGoalAccountThreshold, bool tDDPriceEnable, bool accountGoalPriceEnable, bool flattenWhenGoalAccountReached, bool tradingFromChart, StopOrderTypesTradeSafe stopOrderType, DesiredKeyTradeSafe buyKey, DesiredKeyTradeSafe sellKey, bool enableFlattenPosition, bool averageFIFOPriceEnable, bool ordersHelperEnable, string filenameTargetAlarm, string filenameStopAlarm, string metaFrase0, string stopFrase0)
		{
			return indicator.NTBTradeSafe_EN(input, dailyGoalLossPriceEnable, flattenWhenDailyLossTargetReached, dailyTargetTrading, dailyStopTrading, showTargetStopButtons, placeTargetStopInChart, shortTargetTrade, medTargetTrade, longTargetTrade, shortStopTrade, medStopTrade, longStopTrade, trailPeakPriceEnable, trailStopBarClose, trailStopUnit, trailStopOffset, moveStopMarkersEnable, mvStop1, mvStop2, mvStop3, tDDAgreementTerm, resetRiskInfo, tDDAutoLiquidatePeakBalance, tDDAutoLiquidateThreshold, iSThresholdTrailling, initialBalanceAccount, targetGoalAccountThreshold, tDDPriceEnable, accountGoalPriceEnable, flattenWhenGoalAccountReached, tradingFromChart, stopOrderType, buyKey, sellKey, enableFlattenPosition, averageFIFOPriceEnable, ordersHelperEnable, filenameTargetAlarm, filenameStopAlarm, metaFrase0, stopFrase0);
		}

	}
}

#endregion
