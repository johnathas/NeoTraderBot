#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Indicators.NTBCumulativeDelta[] cacheNTBCumulativeDelta;

		
		public NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(NTBCumDeltaType deltaType)
		{
			return NTBCumulativeDelta(Input, deltaType);
		}


		
		public NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(ISeries<double> input, NTBCumDeltaType deltaType)
		{
			if (cacheNTBCumulativeDelta != null)
				for (int idx = 0; idx < cacheNTBCumulativeDelta.Length; idx++)
					if (cacheNTBCumulativeDelta[idx].deltaType == deltaType && cacheNTBCumulativeDelta[idx].EqualsInput(input))
						return cacheNTBCumulativeDelta[idx];
			return CacheIndicator<NeoTraderBot_Indicators.NTBCumulativeDelta>(new NeoTraderBot_Indicators.NTBCumulativeDelta(){ deltaType = deltaType }, input, ref cacheNTBCumulativeDelta);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(NTBCumDeltaType deltaType)
		{
			return indicator.NTBCumulativeDelta(Input, deltaType);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(ISeries<double> input , NTBCumDeltaType deltaType)
		{
			return indicator.NTBCumulativeDelta(input, deltaType);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(NTBCumDeltaType deltaType)
		{
			return indicator.NTBCumulativeDelta(Input, deltaType);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBCumulativeDelta NTBCumulativeDelta(ISeries<double> input , NTBCumDeltaType deltaType)
		{
			return indicator.NTBCumulativeDelta(input, deltaType);
		}

	}
}

#endregion
