#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private NeoTraderBot_Indicators.NTBiVWAPBands_FREE[] cacheNTBiVWAPBands_FREE;

		
		public NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			return NTBiVWAPBands_FREE(Input, numDeviations, sD1, sD2, sD3, sD4, sD5, vwapPaint, makeTransparent, sD1AreaOpacity, sD1Thickness, sD2AreaOpacity, sD2Thickness, sD3AreaOpacity, sD3Thickness, sD4AreaOpacity, sD4Thickness, sD5AreaOpacity, sD5Thickness);
		}


		
		public NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(ISeries<double> input, int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			if (cacheNTBiVWAPBands_FREE != null)
				for (int idx = 0; idx < cacheNTBiVWAPBands_FREE.Length; idx++)
					if (cacheNTBiVWAPBands_FREE[idx].NumDeviations == numDeviations && cacheNTBiVWAPBands_FREE[idx].SD1 == sD1 && cacheNTBiVWAPBands_FREE[idx].SD2 == sD2 && cacheNTBiVWAPBands_FREE[idx].SD3 == sD3 && cacheNTBiVWAPBands_FREE[idx].SD4 == sD4 && cacheNTBiVWAPBands_FREE[idx].SD5 == sD5 && cacheNTBiVWAPBands_FREE[idx].vwapPaint == vwapPaint && cacheNTBiVWAPBands_FREE[idx].makeTransparent == makeTransparent && cacheNTBiVWAPBands_FREE[idx].SD1AreaOpacity == sD1AreaOpacity && cacheNTBiVWAPBands_FREE[idx].SD1Thickness == sD1Thickness && cacheNTBiVWAPBands_FREE[idx].SD2AreaOpacity == sD2AreaOpacity && cacheNTBiVWAPBands_FREE[idx].SD2Thickness == sD2Thickness && cacheNTBiVWAPBands_FREE[idx].SD3AreaOpacity == sD3AreaOpacity && cacheNTBiVWAPBands_FREE[idx].SD3Thickness == sD3Thickness && cacheNTBiVWAPBands_FREE[idx].SD4AreaOpacity == sD4AreaOpacity && cacheNTBiVWAPBands_FREE[idx].SD4Thickness == sD4Thickness && cacheNTBiVWAPBands_FREE[idx].SD5AreaOpacity == sD5AreaOpacity && cacheNTBiVWAPBands_FREE[idx].SD5Thickness == sD5Thickness && cacheNTBiVWAPBands_FREE[idx].EqualsInput(input))
						return cacheNTBiVWAPBands_FREE[idx];
			return CacheIndicator<NeoTraderBot_Indicators.NTBiVWAPBands_FREE>(new NeoTraderBot_Indicators.NTBiVWAPBands_FREE(){ NumDeviations = numDeviations, SD1 = sD1, SD2 = sD2, SD3 = sD3, SD4 = sD4, SD5 = sD5, vwapPaint = vwapPaint, makeTransparent = makeTransparent, SD1AreaOpacity = sD1AreaOpacity, SD1Thickness = sD1Thickness, SD2AreaOpacity = sD2AreaOpacity, SD2Thickness = sD2Thickness, SD3AreaOpacity = sD3AreaOpacity, SD3Thickness = sD3Thickness, SD4AreaOpacity = sD4AreaOpacity, SD4Thickness = sD4Thickness, SD5AreaOpacity = sD5AreaOpacity, SD5Thickness = sD5Thickness }, input, ref cacheNTBiVWAPBands_FREE);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			return indicator.NTBiVWAPBands_FREE(Input, numDeviations, sD1, sD2, sD3, sD4, sD5, vwapPaint, makeTransparent, sD1AreaOpacity, sD1Thickness, sD2AreaOpacity, sD2Thickness, sD3AreaOpacity, sD3Thickness, sD4AreaOpacity, sD4Thickness, sD5AreaOpacity, sD5Thickness);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(ISeries<double> input , int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			return indicator.NTBiVWAPBands_FREE(input, numDeviations, sD1, sD2, sD3, sD4, sD5, vwapPaint, makeTransparent, sD1AreaOpacity, sD1Thickness, sD2AreaOpacity, sD2Thickness, sD3AreaOpacity, sD3Thickness, sD4AreaOpacity, sD4Thickness, sD5AreaOpacity, sD5Thickness);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			return indicator.NTBiVWAPBands_FREE(Input, numDeviations, sD1, sD2, sD3, sD4, sD5, vwapPaint, makeTransparent, sD1AreaOpacity, sD1Thickness, sD2AreaOpacity, sD2Thickness, sD3AreaOpacity, sD3Thickness, sD4AreaOpacity, sD4Thickness, sD5AreaOpacity, sD5Thickness);
		}


		
		public Indicators.NeoTraderBot_Indicators.NTBiVWAPBands_FREE NTBiVWAPBands_FREE(ISeries<double> input , int numDeviations, double sD1, double sD2, double sD3, double sD4, double sD5, vwapPaintMode vwapPaint, bool makeTransparent, int sD1AreaOpacity, int sD1Thickness, int sD2AreaOpacity, int sD2Thickness, int sD3AreaOpacity, int sD3Thickness, int sD4AreaOpacity, int sD4Thickness, int sD5AreaOpacity, int sD5Thickness)
		{
			return indicator.NTBiVWAPBands_FREE(input, numDeviations, sD1, sD2, sD3, sD4, sD5, vwapPaint, makeTransparent, sD1AreaOpacity, sD1Thickness, sD2AreaOpacity, sD2Thickness, sD3AreaOpacity, sD3Thickness, sD4AreaOpacity, sD4Thickness, sD5AreaOpacity, sD5Thickness);
		}

	}
}

#endregion
